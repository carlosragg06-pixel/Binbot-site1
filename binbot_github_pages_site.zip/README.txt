# BinBot website (GitHub Pages)

## Publish for free
1. Sign in to GitHub and create a **public** repository named `binbot-site`.
2. Choose **Add file → Upload files**.
3. Upload `index.html` and `binbot-poster.png` from this folder.
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
7. Wait for GitHub Pages to publish. Your site URL will look like:
   `https://YOUR-USERNAME.github.io/binbot-site/`

GitHub Pages is free for public repositories. The website is public, so don't upload private information.

## QR code
After the site is live, use its exact published URL to create the QR code. Test the QR code with a phone before printing it. A QR code cannot be finalized until the public URL exists.
